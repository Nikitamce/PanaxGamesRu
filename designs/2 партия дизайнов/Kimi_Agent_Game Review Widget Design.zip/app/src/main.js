const cover = './cover.svg';
const sourceLink = '<a class="widget-link source-link" href="https://backloggd.com/" target="_blank" rel="noopener noreferrer"><span class="source-name">Backloggd</span><span aria-hidden="true">↗</span></a>';
const gameMeta = '<span>2025</span><span>Voidline Studio</span><span>Action RPG</span>';
const score = '<strong class="score-value">8.4</strong>';

const variants = [
  {
    id: 'v1', name: 'Журнальная врезка', tag: 'Редакционный',
    description: 'Спокойный вариант для длинных текстов: книжная антиква, тонкие линейки и рейтинг как автограф рецензента.',
    html: `<article class="game-widget w-editorial" aria-label="Карточка игры Neon Requiem">
      <img class="cover" src="${cover}" alt="Обложка Neon Requiem">
      <div class="editorial-main"><p class="w-kicker">Из базы · <span class="source-name">Backloggd</span></p><h3>Neon Requiem</h3><p class="editorial-deck">Неоновый реквием по последнему городу</p><div class="meta">${gameMeta}</div>${sourceLink}</div>
      <div class="editorial-score"><span>Оценка</span>${score}<small>/ 10</small></div>
    </article>`
  },
  {
    id: 'v2', name: 'Швейцарская сетка', tag: 'Информационный',
    description: 'Строгая модульная таблица. Удобно сканировать глазами: каждая характеристика занимает собственную ячейку.',
    html: `<article class="game-widget w-swiss" aria-label="Карточка игры Neon Requiem">
      <div class="swiss-head"><span>GAME / 025</span><span>DATABASE ENTRY</span></div>
      <div class="swiss-grid"><img class="cover" src="${cover}" alt="Обложка Neon Requiem"><div class="swiss-title"><p>Action RPG · Cyberpunk</p><h3>Neon<br>Requiem</h3><div class="meta">VOIDLINE STUDIO<br>NOVA INTERACTIVE</div></div><div class="swiss-score"><span>USER SCORE</span>${score}<div class="score-track"><i></i></div></div></div>
      <div class="swiss-foot"><span>2025 / OPEN WORLD</span>${sourceLink}</div>
    </article>`
  },
  {
    id: 'v3', name: 'Терминал', tag: 'Технический',
    description: 'Для обзоров инди и киберпанка: моноширинный ритм, диагностические метки и рейтинг в виде загрузочной шкалы.',
    html: `<article class="game-widget w-terminal" aria-label="Карточка игры Neon Requiem">
      <div class="terminal-top"><span>// GAME_PROFILE.EXE</span><span class="terminal-status">● VERIFIED</span></div>
      <div class="terminal-body"><img class="cover" src="${cover}" alt="Обложка Neon Requiem"><div><p class="terminal-path">~/database/rpg/2025</p><h3>NEON_REQUIEM</h3><dl><div><dt>DEVELOPER</dt><dd>Voidline Studio</dd></div><div><dt>PUBLISHER</dt><dd>Nova Interactive</dd></div><div><dt>TAGS</dt><dd>cyberpunk, open-world</dd></div></dl></div></div>
      <div class="terminal-rating"><span>RATING [<i class="terminal-bars">████████░░</i>] <b class="score-value">8.4</b></span>${sourceLink}</div>
    </article>`
  },
  {
    id: 'v4', name: 'Билет в игру', tag: 'Коллекционный',
    description: 'Карточка-сувенир с перфорацией. Подходит для рубрик «что поиграть» и подборок недели.',
    html: `<article class="game-widget w-ticket" aria-label="Карточка игры Neon Requiem">
      <div class="ticket-stub"><span>ADMIT ONE</span><b>NR<br>25</b><small>GAME PASS</small></div>
      <img class="cover" src="${cover}" alt="Обложка Neon Requiem">
      <div class="ticket-info"><p>VOIDLINE STUDIO PRESENTS</p><h3>Neon Requiem</h3><div class="meta"><span>2025</span><span>ACTION RPG</span><span>OPEN WORLD</span></div>${sourceLink}</div>
      <div class="ticket-score"><span>RATING</span>${score}<small class="source-name">Backloggd</small></div>
    </article>`
  },
  {
    id: 'v5', name: 'Кинокадр', tag: 'Атмосферный',
    description: 'Обложка превращается в полноэкранную сцену. Минимум интерфейса — максимум настроения игры.',
    html: `<article class="game-widget w-cinema" aria-label="Карточка игры Neon Requiem">
      <img class="cinema-art" src="./scene.svg" alt="">
      <div class="cinema-shade"></div>
      <div class="cinema-top"><span>A GAME BY VOIDLINE</span><div><b class="score-value">8.4</b><small>/10</small></div></div>
      <div class="cinema-bottom"><p>2025 · ACTION RPG · CYBERPUNK</p><h3>Neon Requiem</h3><div><span class="source-caption">Оценка <span class="source-name">Backloggd</span></span>${sourceLink}</div></div>
    </article>`
  },
  {
    id: 'v6', name: 'Одной строкой', tag: 'Компактный',
    description: 'Тонкая врезка между абзацами. Не спорит с текстом и сохраняет всё необходимое даже на узком экране.',
    html: `<article class="game-widget w-inline" aria-label="Карточка игры Neon Requiem">
      <img class="cover" src="${cover}" alt="Обложка Neon Requiem">
      <div class="inline-title"><p><span class="source-name">Backloggd</span> · 2025</p><h3>Neon Requiem</h3><span>Action RPG · Voidline Studio</span></div>
      <div class="inline-score">${score}<span>/ 10</span></div>${sourceLink}
    </article>`
  },
  {
    id: 'v7', name: 'Нео-брутализм', tag: 'Громкий',
    description: 'Жёсткие рамки, плоский жёлтый и честная тень. Для субкультурных медиа и дерзких авторских колонок.',
    html: `<article class="game-widget w-brutal" aria-label="Карточка игры Neon Requiem">
      <div class="brutal-label">GAME OF THE WEEK!</div>
      <div class="brutal-body"><img class="cover" src="${cover}" alt="Обложка Neon Requiem"><div class="brutal-copy"><p>2025 // VOIDLINE STUDIO</p><h3>NEON<br>REQUIEM</h3><div class="brutal-tags"><span>RPG</span><span>CYBERPUNK</span></div></div><div class="brutal-score">${score}<span>OUT OF 10</span></div></div>
      <div class="brutal-foot"><span class="source-caption">SCORE VIA <b class="source-name">Backloggd</b></span>${sourceLink}</div>
    </article>`
  },
  {
    id: 'v8', name: 'Синий постер', tag: 'Графичный',
    description: 'Асимметричная композиция и электрический синий. Работает как самостоятельная иллюстрация к обзору.',
    html: `<article class="game-widget w-poster" aria-label="Карточка игры Neon Requiem">
      <span class="poster-ghost" aria-hidden="true">NR</span><p class="poster-index">GAME CARD — № 025</p>
      <img class="cover" src="${cover}" alt="Обложка Neon Requiem">
      <div class="poster-copy"><p>VOIDLINE STUDIO / 2025</p><h3>Neon<br>Requiem</h3><span>Action RPG · Cyberpunk<br>Open world</span></div>
      <div class="poster-score">${score}<span>USER RATING<br><span class="source-name">Backloggd</span></span></div>
      <div class="poster-link">${sourceLink}</div>
    </article>`
  },
  {
    id: 'v9', name: 'Рейтинговый док', tag: 'Утилитарный',
    description: 'Тёмная панель с круговым индикатором. Хорошо смотрится в сайдбаре и под итогами рецензии.',
    html: `<article class="game-widget w-dock" aria-label="Карточка игры Neon Requiem">
      <img class="cover" src="${cover}" alt="Обложка Neon Requiem">
      <div class="dock-info"><p>GAME PROFILE / 2025</p><h3>Neon Requiem</h3><span>Voidline Studio · Action RPG</span><div class="dock-platforms">PC&nbsp;&nbsp; PS5&nbsp;&nbsp; XSX</div></div>
      <div class="dock-score"><svg viewBox="0 0 80 80" aria-hidden="true"><circle cx="40" cy="40" r="34"></circle><circle class="dock-progress" cx="40" cy="40" r="34"></circle></svg><div>${score}<span class="source-name">Backloggd</span></div></div>
      ${sourceLink}
    </article>`
  },
  {
    id: 'v10', name: 'Картридж', tag: 'Игровой',
    description: 'Форма носителя из девяностых, но с современной типографикой. Немного ностальгии без пиксельного клише.',
    html: `<article class="game-widget w-cartridge" aria-label="Карточка игры Neon Requiem">
      <div class="cartridge-grip"><i></i><i></i><i></i><i></i><i></i></div>
      <div class="cartridge-label"><img class="cover" src="${cover}" alt="Обложка Neon Requiem"><div><p>VOIDLINE / NR-2025</p><h3>NEON REQUIEM</h3><span>ACTION RPG · 1 PLAYER</span></div><div class="cartridge-score">${score}<small>/10</small></div></div>
      <div class="cartridge-foot"><span>RATING SOURCE: <b class="source-name">Backloggd</b></span>${sourceLink}</div>
    </article>`
  }
];

const gallery = document.querySelector('#gallery');
gallery.innerHTML = variants.map((variant, index) => `
  <section class="variant" id="${variant.id}" aria-labelledby="${variant.id}-title">
    <header class="variant-header"><span class="variant-number">${String(index + 1).padStart(2, '0')}</span><div><p>${variant.tag}</p><h2 id="${variant.id}-title">${variant.name}</h2></div></header>
    <p class="variant-description">${variant.description}</p>
    <div class="widget-stage">${variant.html}</div>
  </section>`).join('');

const sourceData = {
  backloggd: { name: 'Backloggd', score: '8.4', href: 'https://backloggd.com/', bars: '████████░░', progress: 84 },
  panaax: { name: 'Panaaxgames', score: '8.7', href: 'https://panaaxgames.com/', bars: '█████████░', progress: 87 }
};

function setSource(key, notify = true) {
  const data = sourceData[key];
  document.querySelectorAll('.source-name').forEach(el => { el.textContent = data.name; });
  document.querySelectorAll('.score-value').forEach(el => { el.textContent = data.score; });
  document.querySelectorAll('.source-link').forEach(el => { el.href = data.href; el.setAttribute('aria-label', `Открыть ${data.name} в новой вкладке`); });
  document.querySelectorAll('.terminal-bars').forEach(el => { el.textContent = data.bars; });
  document.querySelectorAll('.dock-progress').forEach(el => { el.style.strokeDasharray = `${data.progress * 2.136} 213.6`; });
  document.querySelectorAll('.score-track i').forEach(el => { el.style.width = `${data.progress}%`; });
  document.querySelectorAll('.source-button').forEach(button => {
    const active = button.dataset.source === key;
    button.classList.toggle('is-active', active);
    button.setAttribute('aria-pressed', String(active));
  });
  if (notify) {
    const toast = document.querySelector('#toast');
    toast.textContent = `Источник: ${data.name}`;
    toast.classList.add('is-visible');
    clearTimeout(setSource.toastTimer);
    setSource.toastTimer = setTimeout(() => toast.classList.remove('is-visible'), 1800);
  }
}

document.querySelectorAll('.source-button').forEach(button => button.addEventListener('click', () => setSource(button.dataset.source)));
document.querySelector('#variant-jump').addEventListener('change', event => document.querySelector(`#${event.target.value}`).scrollIntoView({ behavior: 'smooth', block: 'start' }));

const links = [...document.querySelectorAll('#side-links a')];
const observer = new IntersectionObserver(entries => {
  const visible = entries.filter(entry => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
  if (!visible) return;
  links.forEach(link => link.classList.toggle('is-current', link.getAttribute('href') === `#${visible.target.id}`));
}, { rootMargin: '-15% 0px -65% 0px', threshold: [0, 0.1, 0.5] });
document.querySelectorAll('.variant').forEach(section => observer.observe(section));
setSource('backloggd', false);
